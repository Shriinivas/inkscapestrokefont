#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
Defintion of Common functions and variables used by stroke font extensions

Copyright (C) 2019  Shrinivas Kulkarni

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
'''

import inkex, sys, os, fileinput, re, locale
from xml.dom.minidom import parse, Document
from cubicsuperpath import CubicSuperPath, formatPath
from simplepath import parsePath

class CommonDefs:
    extXmlFileName = 'render_stroke_font_text.inx'
    
    vgScaleFact = 2.
    guideAttribName = 'guide'
    hGuideAttrib = 'h'
    lvGuideAttrib = 'lv'
    rvGuideAttrib = 'rv'
    hSeqAttribName = 'hSeq'
    vSeqAttribName = 'vSeq'

    dataFileDir = 'strokefontdata'
    ##### XML Data Constants ########
    xFont = 'font'
    xName = 'name'
    xSize = 'size'
    xGlyph = 'glyph'
    xChar = 'char'
    xROff = 'rOff'
    xBBox = 'bbox'
    xCRInfo = 'crinfo'
    
    #### XML Comment ####
    xHeader = 'The data file defining the stroke font: '

    encoding = sys.stdin.encoding
    if(encoding == 'cp0' or encoding is None):
        encoding = locale.getpreferredencoding()

def getDataFileDirPath(extPath):
    return extPath + '/' + CommonDefs.dataFileDir
    
def getDataFilePath(extPath, fontName):
    return extPath + '/' + CommonDefs.dataFileDir + '/' + fontName +'.xml'
    
def getDecodedChars(chars):
    return chars.decode(CommonDefs.encoding)

def indentStr(cnt):
    ostr = ''
    for i in range(0, cnt):
        ostr += '    '
    return ostr
    
def syncFontList(extPath):
    sectMarker = '<!-- ##! dynamically generated portion'

    found = False
    outStr = indentStr(1) + sectMarker + ' [start] -->\n'
    xmlFilePath = extPath + "/" + CommonDefs.extXmlFileName
    dataFileDirPath = getDataFileDirPath(extPath)
    
    try:
        fontNames = [fname[:-4] for fname in os.listdir(dataFileDirPath) if fname.endswith('.xml')]

        for fName in fontNames:
            outStr += indentStr(2) + '<item value="' + fName + '">' + fName + '</item>\n'
    
        outStr += indentStr(1) + sectMarker + ' [end] -->\n'
    
        for line in fileinput.input(xmlFilePath, inplace = 1):
            if sectMarker in line:
                if(found):
                    print outStr,
                    found = False
                else:
                    found = True
            else:
                if(not found):
                    print line,

    except Exception as e:
        inkex.errormsg('Error updating font list...\n' + str(e))

def scaleGlyph(glyphD, scaleFactor):
    
    cspath = CubicSuperPath(parsePath(glyphD))
    for subpath in cspath:
        for bezierPts in subpath:
            for i in range(0, len(bezierPts)):
                #No worries about origin...
                bezierPts[i] = [bezierPts[i][0] * scaleFactor, 
                    bezierPts[i][1] * scaleFactor]                    
    return formatPath(cspath)
    
class CharData:
    
    def __init__(self, bbox, rOffset, pathStr):
        self.bbox = bbox
        self.rOffset = rOffset
        self.pathStr = pathStr

class FontData:
    
    def __init__(self, extPath, fontName, fontSize):
        
        self.dataFilePath = getDataFilePath(extPath, fontName)
        self.fontName = fontName
        self.glyphMap = {}
        self.fontSize = fontSize
        self.crInfo = ''
        fontElem = None
        
        dataFileDirPath = getDataFileDirPath(extPath)        
        if(not os.path.isdir(dataFileDirPath)):
            os.makedirs(dataFileDirPath)

        try:
            with open(self.dataFilePath) as xml:
                dataDoc = parse(xml)        
            fontElem = dataDoc.getElementsByTagName(CommonDefs.xFont)[0]
        except:
            pass
            
        if(fontElem != None):
            crElem = fontElem.getElementsByTagName(CommonDefs.xCRInfo)[0]
            if(len(crElem.childNodes) > 0):
                self.crInfo = crElem.childNodes[0].nodeValue
            
            oldFontSize = float(fontElem.getAttribute(CommonDefs.xSize))

            glyphElems = fontElem.getElementsByTagName(CommonDefs.xGlyph)
            
            regEx = re.compile('\(([^,]+),([^,]+),([^,]+),([^,]+)\)')
            for e in glyphElems:
                char = e.getAttribute(CommonDefs.xChar)
                
                rOffset = float(e.getAttribute(CommonDefs.xROff))

                bboxStr =  e.getAttribute(CommonDefs.xBBox)
                res = regEx.findall(bboxStr)
                bbox = [float(b) for b in res[0]]
                
                pathStr = e.childNodes[0].data
                
                #Scale if needed
                if(oldFontSize != fontSize):
                    pathStr = scaleGlyph(pathStr, fontSize / oldFontSize)
                    rOffset = rOffset * fontSize / oldFontSize
                    bbox = [b * fontSize / oldFontSize for b in bbox]

                self.glyphMap[char] = CharData(bbox, rOffset, pathStr)

    def updateGlyph(self, char, bbox, rOffset, pathStr):
        self.glyphMap[char] = CharData(bbox, rOffset, pathStr)
        
    def setCRInfo(self, crInfo):
        if(crInfo  != None and crInfo != ''):
            self.crInfo = crInfo
            
    def hasGlyphs(self):
        return len(self.glyphMap) > 0
        
    def updateFontXML(self):
        dataDoc = Document()
        dataDoc.appendChild(dataDoc.createComment(CommonDefs.xHeader + self.fontName))

        fontElem = dataDoc.createElement(CommonDefs.xFont)
        dataDoc.appendChild(fontElem)

        fontElem.setAttribute(CommonDefs.xSize, str(self.fontSize))
        fontElem.setAttribute(CommonDefs.xName, self.fontName)

        crElem = dataDoc.createElement(CommonDefs.xCRInfo)
        fontElem.appendChild(crElem)            

        if (self.crInfo != ''):
            crElem.appendChild(dataDoc.createTextNode(self.crInfo))
        
        for char in self.glyphMap:
            charData = self.glyphMap[char]
            glyphElem = dataDoc.createElement(CommonDefs.xGlyph)
            fontElem.appendChild(glyphElem)
            
            glyphElem.setAttribute('char', char)                
            glyphElem.setAttribute(CommonDefs.xROff, str(charData.rOffset))
            glyphElem.setAttribute(CommonDefs.xBBox, \
                '('+','.join([str(round(b, 2)) for b in charData.bbox])+')')
                
            glyphElem.appendChild(dataDoc.createTextNode(charData.pathStr))
        
        f = open(self.dataFilePath, "w")
        f.write(dataDoc.toxml(encoding="utf-8"))
        f.close()
        
            
