#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
Inkscape extension to edit a stroke font
Dependencies: stroke_font_common.py and stroke_font_manager.py

Copyright (C) 2019  Shrinivas Kulkarni

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
'''

from inkex import Effect, addNS, etree
import sys, os, simplepath
from simplestyle import formatStyle


sys.path.append(os.path.dirname(os.path.abspath(__file__))) 
from stroke_font_common import CommonDefs, InkscapeCharDataFactory, createTempl
from stroke_font_manager import FontData

class EditStrokeFont(Effect):

    def __init__(self):
        Effect.__init__(self)

        self.OptionParser.add_option( "--fontName",
            action="store", type="string",
            dest="fontName", default = 'Script', 
            help="The custom font to edit")

        self.OptionParser.add_option('--rowCnt', action = 'store',
          type = 'int', dest = 'rowCnt', default = '5',
          help = 'Number of rows (horizontal guides) in the template')

        self.OptionParser.add_option('--fontSize', action = 'store',
          type = 'int', dest = 'fontSize', default = '100',
          help = 'Size of the source glyphs to be rendered')

        self.OptionParser.add_option("--tab", action="store", 
          type="string", dest="tab", default="sampling", help="Tab") 
          
    def addElem(self, templLayer, editLayer, glyphIdx, posX, posY):
        char = self.fontChars[glyphIdx]
        charData = self.strokeFontData.glyphMap[char]
        
        pp = simplepath.parsePath(charData.pathStr)
        simplepath.translatePath(pp, posX, posY)
        d = simplepath.formatPath(pp)

        attribs = {'id':char, 'style':formatStyle(self.charStyle), 'd':d}
        etree.SubElement(editLayer, addNS('path','svg'), attribs) 
            
        return charData.rOffset


    def effect(self):
        rowCnt = self.options.rowCnt
        fontName = self.options.fontName
        fontSize = self.options.fontSize
        
        lineT = CommonDefs.lineT * fontSize
        strokeWidth = 0.02 * fontSize
        self.charStyle = { 'stroke': '#000000', 'fill': 'none', \
            'stroke-width':strokeWidth, 'stroke-linecap':'round', \
                'stroke-linejoin':'round'}

        vgScaleFact = CommonDefs.vgScaleFact        
        
        extPath = os.path.dirname(os.path.abspath(__file__))
        self.strokeFontData = FontData(extPath, fontName, fontSize, InkscapeCharDataFactory())        
        self.fontChars = sorted(self.strokeFontData.glyphMap.keys())
        
        glyphCnt = len(self.fontChars)
        
        createTempl(self.addElem, self, fontSize, rowCnt, glyphCnt, vgScaleFact, True, lineT)
    
effect = EditStrokeFont()
effect.affect()
